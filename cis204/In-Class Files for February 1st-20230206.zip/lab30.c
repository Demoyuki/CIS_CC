/*	Write a program that calculates the area and the perimeter of a
		rectangle from a user-supplied (scanf) length and width.
		NOTE: Discuss integer versus float
	Filename: lab30.c
	Written by: Dan Guilmette
	Date: February 1st, 2023
*/
#include <stdio.h>

int main (void)
{
	// Local Definitions
	int length = 0;
	int width = 0;
	int area = 0;
	int perimeter = 0;
		
	// Statements
	// user prompt for length
	printf("\nEnter the length of the rectangle: ");
	// get rectangle length from user
	scanf("%d", &length);
	// user prompt for width
	printf("\nEnter the width of the rectangle: ");
	// get rectangle width from user
	scanf("%d", &width);
	// calculate area
	area = length * width;
	// calculate perimeter
	perimeter = (2 * length) + (2 * width);
	// display results
	printf("\nThe area of the rectangle = %d", area);
	printf("\nThe perimeter of the rectangle = %d", perimeter);
	
	// end of program message
	printf("\nThis ends the program\n");
	
	return 0;
} // end of main